
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.applications import VGG19
from tensorflow.keras.preprocessing.image import ImageDataGenerator
image_size = (224, 224)  # resize all images
batch_size = 8
epochs=20

# Define the data generator for preprocessing
train_datagen = ImageDataGenerator(
    rescale=1.0/255.0,
    rotation_range=15,
    width_shift_range=0.1,
    height_shift_range=0.1,
    zoom_range=0.2,
    validation_split=0.1
)

#convert to NumPy arrays
train_data = train_datagen.flow_from_directory(
    "G:\Documents\E-yantra\2023(Geoguide)\Task 2\Task 2B\Data sets",
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical',
    subset='training',
    shuffle=True
)
val_data = train_datagen.flow_from_directory(
    "G:\Documents\E-yantra\2023(Geoguide)\Task 2\Task 2B\Data sets",
    target_size=image_size,
    batch_size=batch_size,
    class_mode='categorical',
    subset='validation',
    shuffle=True
)
base_model = VGG19(weights='imagenet', include_top=False, input_shape=(image_size[0], image_size[1], 3))


for layer in base_model.layers:
    layer.trainable = False

model = keras.Sequential([
    base_model,
    keras.layers.GlobalAveragePooling2D(),
    keras.layers.Dense(128, activation='relu'),
    keras.layers.Dropout(0.2),
    keras.layers.Dense(5, activation='softmax')
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

history = model.fit(train_data, epochs=epochs, validation_data=val_data)
model.save('trained_model_with_pretrained_VGG19.h5')


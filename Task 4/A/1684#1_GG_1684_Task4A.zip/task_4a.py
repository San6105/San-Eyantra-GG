'''
*****************************************************************************************
*
*        		===============================================
*           		Geo Guide (GG) Theme (eYRC 2023-24)
*        		===============================================
*
*  This script is to implement Task 4A of Geo Guide (GG) Theme (eYRC 2023-24).
*  
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or 
*  breach of the terms of this agreement.
*
*****************************************************************************************
'''

# Team ID:			[ 1684 ]
# Author List:		[ RASSWANTH G, ANBUSELVAN P, SARAVANAN S, HILSTIENE,M ]
# Filename:			task_4a.py


####################### IMPORT MODULES #######################
import cv2
import numpy as np
from tensorflow import keras
                               
##############################################################

detected_list=[]
squares=[]
keyy=["A","B","C","D","E"]
combat = "combat"
rehab = "humanitarianaid"
military_vehicles = "militaryvehicles"
fire = "fire"
destroyed_building = "destroyedbuilding"
text="nothing"

def classify_event(image):
    model_path = r'C:\eyantra\4A\model.h5'  # Update with your model path
    model = keras.models.load_model(model_path)
    # Resize and preprocess the image
    img_array = cv2.resize(image, (50, 50)) # Resize the image
    img_array = img_array / 255.0  # Normalize the image
    img_array = np.expand_dims(img_array, axis=0)  # Add a batch dimensiona
    # Make predictions using the loaded model

    predictions = model.predict(img_array)

    # Map the model's output to event classes.
    # Replace the following logic with your class mapping.
    event_classes = ["combat", "destroyedbuilding", "fire", "humanitarianaid", "militaryvehicles"]  # Update with your event class labels
    predicted_class_index = np.argmax(predictions)
    predicted_event = event_classes[predicted_class_index]
    
    return predicted_event
def classification(imge):
    global text
    detected_event = classify_event(imge)
    if detected_event == combat:
        text="combat"
        detected_list.append(5)
    if detected_event == rehab:
        text="human_aid_rehabilitation"
        detected_list.append(3)
    if detected_event == military_vehicles:
        text="military_vehicles"
        detected_list.append(4)
    if detected_event == fire:
        text="fire"
        detected_list.append(1)
    if detected_event == destroyed_building:
        text="destroyed_building"
        detected_list.append(2)

def task_4a_return():

    identified_labels = {}  

    detected_list.sort()
    if len(detected_list) == 5:
        for i in range(5):
            if detected_list[i]==1:
                identified_labels[keyy[i]]="fire"
            elif  detected_list[i]==2:
                identified_labels[keyy[i]]="destroyed_buildings"
            elif detected_list[i]==3:
                identified_labels[keyy[i]]="human_aid_rehabilitation"
            elif detected_list[i]==4:
                identified_labels[keyy[i]]="military_vehicles"
            elif detected_list[i]==5:
                identified_labels[keyy[i]]="combat"
    return identified_labels
def detected_event(x, y, width, height):
    imge = frame[y:y+height, x:x+width]
    classification(imge)
    image = cv2.rectangle(frame, (x, y), (x + width, y + height), (0,255,0), 4)
    cv2.putText(image, text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)
    cv2.waitKey(1)  
###############	Main Function	#################
if __name__ == "__main__":
    cap=cv2.VideoCapture(0)
    cv2.namedWindow('camera feed', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('camera feed', 800, 600)
    while cap.isOpened():
        ret,frame=cap.read()
        for i in range(0,5):
            if i==0:
                x, y, width, height = 198, 77, 33, 33
                detected_event(x, y, width, height)

            elif i==1:
                x, y, width, height = 191, 226, 33, 33
                detected_event(x, y, width, height)
            elif i==2:
                x, y, width, height = 417, 230, 33, 33
                detected_event(x, y, width, height)
            elif i==3:
                x, y, width, height = 413, 327, 34, 34
                detected_event(x, y, width, height)
            else:
                x, y, width, height = 195, 420, 33,33 
                
                
                detected_event(x, y, width, height)


        cv2.imshow('camera feed',frame)
        identified_labels = task_4a_return()
        print(identified_labels)
        detected_list.clear()
        key = cv2.waitKey(1) & 0xFF
        if key == ord("a"):
	        break

cv2.destroyAllWindows(1)
cap.release()
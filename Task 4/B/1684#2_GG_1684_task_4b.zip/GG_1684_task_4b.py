import cv2
import numpy as np
import csv

def find_nearest_aruco_id(frame, target_id=369):
    corners, ids, _ = cv2.aruco.detectMarkers(frame, aruco_dict, parameters=aruco_params)
    target_corners = [corners[i] for i in range(len(ids)) if ids[i] == target_id]
    distances = []
    for i in range(len(target_corners)):
        target_center = np.mean(target_corners[i][0], axis=0)
        for j in range(len(corners)):
            if ids[j] != target_id:
                center = np.mean(corners[j][0], axis=0)
                distance = np.linalg.norm(target_center - center)
                distances.append((distance, ids[j]))

    if len(distances) > 0:
        nearest_id = min(distances)[1]
        return int(nearest_id.item())
    else:
        return None



def get_lat_lon(csv_file, target_id):
    with open(csv_file, 'r', encoding='utf-8-sig') as file:
        reader = csv.DictReader(file)
        for row in reader:
            if 'id' in row and row['id'] == target_id:
                return float(row['lat']), float(row['lon'])

    return None
def new_write(coordinate, csv_name):    
    with open(csv_name, 'w') as file:
            csv_writer = csv.writer(file) 
            csv_writer.writerow(['lat','lon'])
            csv_writer.writerow(coordinate)

def tracker_id_369(lat_lon, csv_name='C:\\eyantra\\all_data.csv'):
    coordinate = lat_lon
    with open(csv_name, 'a', newline='') as file:
        csv_writer = csv.writer(file)
        csv_writer.writerow(coordinate)
    new_write(coordinate,r'C:\eyantra\live_data.csv')
    return coordinate


if __name__ == "__main__":
    aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_1000)
    aruco_params = cv2.aruco.DetectorParameters()
    cap = cv2.VideoCapture(0)
    cv2.namedWindow('camera feed', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('camera feed', 800, 600)
    while True:
        ret, frame = cap.read()
        nearest_id = find_nearest_aruco_id(frame)
        cv2.imshow('camera feed', frame)
        if nearest_id is not None:
            result = get_lat_lon(r'C:\eyantra\lat_long.csv', str(nearest_id))
            if result is not None:
                lat, lon = result
                lat_lon = [str(lat), str(lon)]
                tracker_id_369(lat_lon)
            else:
                print("Unable to get latitude and longitude from the provided ID.")
        else:
            print("No ArUco marker detected.")

        if cv2.waitKey(1) & 0xFF == ord('a'):
            break
cv2.destroyAllWindows(1)
cap.release()